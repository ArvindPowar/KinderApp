//
//  MainNavigationController.h
//  MyRodeo
//
//  Created by mansoor shaikh on 09/01/14.
//  Copyright (c) 2014 ClientsSolution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
@interface MainNavigationController : UINavigationController
@property(nonatomic,retain) AppDelegate *appDelegate;
@end
